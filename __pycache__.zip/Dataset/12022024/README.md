# Initial dataset 12022024

INIT_DS_SITTING_#: contains idle sitting readouts with 4 versions (sensor kept at 4 different orientations)
INIT_DS_STANDING_#: contains idle standing with very minute movement readouts with 4 versions (sensor kept at 4 different orientations)
INIT_SIT_STAND_TRANSITION_#: contains readouts of sitting to standing transition with 4 versions (sensor kept at 4 different orientations)
INIT_STAND_SIT_TRANSITION_#: contains readouts of standing to sitting transition with 4 versions (sensor kept at 4 different orientations)
INIT_SLEEP_#: contains readouts of idle sleeping position with 4 versions (sensor kept at 4 different orientations)
INIT_SLEEP_TRANSITION_#: contains left or right turning while sleeping (turning left side or right side during sleep) with 4 versions (sensor kept at 4 different orientations)

Timestamp,Sequence,AcX,AcY,AcZ,GyX,GyY,GyZ,RSSI,SNR

AcX, AcY and AcZ are the x,y,z components of the acceleration (measures acceleration in coordinates)
GyX, GyY and GyZ are the x,y,z components of the gyroscope (measures rotational speed around X, Y, and Z axes of the device)
RSSI is the Received Signal Strength Indicator (a measure of the wireless signal strength)
SNR is the Signal-to-Noise ratio (a measure of the wireless interference)