# datasets



This are the parameters:

Timestamp,Sequence,AcX,AcY,AcZ,GyX,GyY,GyZ,RSSI,SNR

AcX, AcY and AcZ are the x,y,z components of the acceleration (measures acceleration in coordinates)
GyX, GyY and GyZ are the x,y,z components of the gyroscope (measures rotational speed around X, Y, and Z axes of the device)
RSSI is the Received Signal Strength Indicator (a measure of the wireless signal strength)
SNR is the Signal-to-Noise ratio (a measure of the wireless interference)