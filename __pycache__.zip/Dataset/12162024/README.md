# Device datasets 12162024

Note: All datasets contain data with only one fall per session, and all falls are low-intensity, meaning the person acted out the fall and fell gently without experiencing an actual fall. 

'#' represents a perticular session.

DS_DEVICE_DROP_ON_BED_#  Contains datasets of device thrown on bed which represents similar to a person falling.
DS_STAND_FALL_# Contains datasets of an actual person falling down while standing still.
DS_WALK_FALL_# Contains datasets of an actual person falling down while walking at slow pace.
DS_BRISK-WALK_FALL_# Contains datasets of an actual person falling down while walking at a good pace (Brisk walk).
DS_FALL_ON_BED_# Contains datasets of an actual person falling on to a bed.

This are the parameters:

Timestamp,Sequence,AcX,AcY,AcZ,GyX,GyY,GyZ,RSSI,SNR

AcX, AcY and AcZ are the x,y,z components of the acceleration (measures acceleration in coordinates)
GyX, GyY and GyZ are the x,y,z components of the gyroscope (measures rotational speed around X, Y, and Z axes of the device)
RSSI is the Received Signal Strength Indicator (a measure of the wireless signal strength)
SNR is the Signal-to-Noise ratio (a measure of the wireless interference)
