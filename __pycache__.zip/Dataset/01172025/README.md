# datasets



This are the parameters:

Timestamp,Sequence,Acceleration, Angular velocit, State.

Acceleration represents the magnitude of the device’s acceleration, calculated as the modulus of its x, y, and z components, which measure acceleration in three-dimensional coordinates.

Angular Velocity represents the magnitude of the device’s rotational speed, calculated as the modulus of its x, y, and z components, which measure the rate of rotation around the three axes of the device.

State indicates whether the device is in a fall state; if a fall is detected, the value is 1, otherwise, it is 0.
